#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv('UDISE_plus-15-16_infra_barddhaman_wb.csv')
df = pd.DataFrame(data, columns= ['School_Category_Id','School_Management_Id','School_Type_Id'])
category = df.iloc[:,2]
n = len(category)

category_boys = array = [0 for i in range(n)] 
management_boys = [0 for i in range(n)]
j= 0

category_girls = [0 for i in range(n)]
management_girls = [0 for i in range(n)]
k=0

category_coed = [0 for i in range(n)]
management_coed = [0 for i in range(n)]
l=0

for i in range(n):
    cat = category[i]
    if (cat == 1):
        category_boys[j] = df.iloc[i,0]
        management_boys[j] = df.iloc[i,1]
        j +=1
    elif (cat == 2):
        category_girls[k] = df.iloc[i,0]
        management_girls[k] = df.iloc[i,1]
        k +=1
    else:
        category_coed[l] = df.iloc[i,0]
        management_coed[l] = df.iloc[i,1]
        l +=1
      
dictionary_boys = dict(zip(category_boys, management_boys)) 
dictionary_girls = dict(zip(category_girls, management_girls)) 
dictionary_coed = dict(zip(category_coed, management_coed)) 

category_boys = dictionary_boys.keys()
management_boys = dictionary_boys.values()

category_girls = dictionary_girls.keys()
management_girls = dictionary_girls.values()

category_coed = dictionary_coed.keys()
management_coed = dictionary_coed.values()


a = plt.scatter(category_boys, management_boys, c ="pink", linewidths = 2, marker ="s", edgecolor ="green", s = 50)
b = plt.scatter(category_girls, management_girls, c ="yellow",linewidths = 2,marker ="^", edgecolor ="red", s = 200)
c = plt.scatter(category_coed, management_coed, c ="black",linewidths = 2,marker ="*", edgecolor ="red", s = 200)    

plt.legend((a, b, c),('boys', 'girls','co-ed'))
plt.grid(which='minor',axis='both',linestyle='--',alpha=0.2)
plt.grid(which='major',axis='y',linestyle='-',alpha=0.5)
plt.minorticks_on()
plt.ylabel("School management id")
plt.xlabel("School category id")
plt.title("Classification of school type id based on school category id and school management id")
plt.show()

plt.rcParams['figure.figsize'] = [18, 12]


# In[ ]:




