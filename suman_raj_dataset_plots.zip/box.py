#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
 
 
# Creating dataset
data = pd.read_csv('TableNo13A_TRAFFIC_HANDLED_AT_NON-MAJOR_PORTS-COMMODITY_WISE_GUJARAT_0.csv')
petroleum = data.iloc[:,1]
iron = data.iloc[:,2]
building_material = data.iloc[:,3]
coal = data.iloc[:,4]
fertilizer = data.iloc[:,5]
others = data.iloc[:,6]

cargo = [petroleum, iron, building_material,coal,fertilizer,others]

plt.boxplot(cargo)
plt.xticks([1, 2, 3, 4, 5, 6], ['petroleum', 'iron', 'building_material', 'coal', 'fertilizer', 'others'])
plt.grid(which='minor',axis='both',linestyle='--',alpha=0.2)
plt.grid(which='major',axis='y',linestyle='-',alpha=0.5)
plt.minorticks_on()
plt.ylabel("Cargo Handled per material distribution(in thousand tonnes)")
plt.xlabel("Different types of cargo")
plt.title("Box plot for Commodity-wise Traffic handled at Non-Major Ports in Gujarat from 1959-60 to 2019-20 ")
 
# show plot
plt.show()
plt.rcParams['figure.figsize'] = [18, 12]


# In[ ]:




