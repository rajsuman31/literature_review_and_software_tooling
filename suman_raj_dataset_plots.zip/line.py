#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


data = pd.read_csv('TableNo13A_TRAFFIC_HANDLED_AT_NON-MAJOR_PORTS-COMMODITY_WISE_GUJARAT_0.csv')

df = pd.DataFrame(data, columns= ['Year/Ports','Total Cargo Handled'])
year = df.iloc[31:61,0]
cargo = df.iloc[31:61,1]
    

plt.xlabel("year/ports")
plt.ylabel("Total Cargo Handled (in thousand tonnes)")
plt.xticks(rotation=90)
plt.plot(year, cargo,'y', marker = ".")
plt.grid(which='minor',axis='both',linestyle='--',alpha=0.2)
plt.grid(which='major',axis='y',linestyle='-',alpha=0.5)
plt.minorticks_on()
plt.title("Line plot for Commodity-wise Traffic handled at Non-Major Ports in Gujarat from 1990-91 to 2019-20 ")
plt.show()
plt.rcParams['figure.figsize'] = [18, 12]


# In[ ]:




